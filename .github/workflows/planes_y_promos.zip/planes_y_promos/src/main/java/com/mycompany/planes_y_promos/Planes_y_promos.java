/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.planes_y_promos;

/**
 *
 * @author cesar
 */
public class Planes_y_promos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
